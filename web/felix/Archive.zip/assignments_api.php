<?php
require_once __DIR__ . '/assignments_auth.php';
require_once __DIR__ . '/assignments_db.php';
require_once __DIR__ . '/assignment_roster.php';
header('Content-Type: application/json; charset=utf-8');
function assignmentError(int $status, string $message): void {
    http_response_code($status);
    echo json_encode(['error' => $message], JSON_UNESCAPED_UNICODE);
    exit;
}
$method = $_SERVER['REQUEST_METHOD'];
if (!in_array($method, ['GET', 'POST'], true)) { header('Allow: GET, POST'); assignmentError(405, 'Nem támogatott kérés.'); }
if ($method === 'POST' && !validLoginCsrf()) assignmentError(403, 'A biztonsági munkamenet lejárt. Töltse újra az oldalt.');
$date = ($method === 'POST' ? $_POST['date'] ?? '' : $_GET['date'] ?? '');
if ($date !== '' && !felixValidFilmingDate($date)) assignmentError(400, 'Érvénytelen forgatási nap.');
try {
    $db = felixAssignmentsDb();
    if ($date === '') $date = felixDefaultFilmingDate($db);
    $day = felixFilmingDay($db, $date);
    if ($method === 'POST') {
        $id = $_POST['person_id'] ?? '';
        $action = $_POST['action'] ?? '';
        if (!is_string($id) || !ctype_digit($id) || (int)$id < 1 || !in_array($action, ['assign','remove'], true)) assignmentError(400, 'Érvénytelen személy vagy művelet.');
        $query = $db->prepare('SELECT id FROM felix_people WHERE id=?');
        $query->execute([$id]);
        if (!$query->fetch()) assignmentError(400, 'A személy nem található.');
        $file = felixAssignmentRosterTransaction($db, $date, $authenticatedUser, function (PDO $db) use ($date, $action, $id, $authenticatedUser) {
        $day = felixFilmingDay($db, $date);
        if ($action === 'assign') {
            // Resolve the unique date inside the transaction, including races.
            $query = $db->prepare('INSERT INTO felix_filming_days (date,title) VALUES (?,?) ON DUPLICATE KEY UPDATE date=VALUES(date)');
            $query->execute([$date, 'Forgatási nap']);
            $query = $db->prepare('SELECT id FROM felix_filming_days WHERE date=?');
            $query->execute([$date]);
            $day['id'] = $query->fetchColumn();
            $query = $db->prepare('INSERT INTO felix_day_assignments (day_id,person_id,assigned_by) VALUES (?,?,?) ON DUPLICATE KEY UPDATE person_id=VALUES(person_id)');
            $query->execute([$day['id'], $id, $authenticatedUser]);
        } elseif ($day['id'] !== null) {
            $query = $db->prepare('DELETE FROM felix_day_assignments WHERE day_id=? AND person_id=?');
            $query->execute([$day['id'], $id]);
        }
        });
        echo json_encode(['ok' => true, 'file' => $file]);
        exit;
    }
    $search = $_GET['q'] ?? '';
    if (!is_string($search) || mb_strlen($search) > 120) assignmentError(400, 'A keresés legfeljebb 120 karakter lehet.');
    $query = $db->prepare('SELECT id,name,city,fictional FROM felix_people WHERE LOCATE(?,name)>0 OR LOCATE(?,city)>0 ORDER BY name');
    $query->execute([$search,$search]);
    $people = $query->fetchAll();
    echo json_encode(['day' => $day, 'people' => $people, 'assigned' => felixFilmingAssigned($db, $day['id'])], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    if (isset($db) && $db->inTransaction()) $db->rollBack();
    if (in_array($e->getCode(), [409, 423], true)) assignmentError($e->getCode(), $e->getMessage());
    error_log('Felix assignment/roster failure: ' . get_class($e));
    assignmentError(503, 'Az adatbázis most nem érhető el. Próbálja újra később.');
}
