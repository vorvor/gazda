# Forgatási nap beosztása

URL: `/felix/assignments.php` (link in Elek's roster header).
Uses the existing Felix login. Only authenticated **Elek** is authorized by a
server-side allowlist, independently of display-role labels. No new credentials.

## Storage / setup

Real MySQL tables, separate from Drupal and CSV rosters:
`felix_people`, `felix_filming_days`, `felix_day_assignments`.
A composite primary key prevents duplicate person/day assignments, including
concurrent requests. Foreign keys reject orphan assignments. SQL is prepared.

Private configuration: `/workspace/private/felix-db.php` (outside the web root,
ignored by Git, mode 0640). It returns PHP array keys `host`, `port`, `database`,
`username`, `password`; values were copied securely from the existing configured
Drupal connection without printing them. Runtime may override the absolute path
with `FELIX_DB_CONFIG`. Grant the web-server user read access when deploying; do
not put this configuration in `web/` or commit credentials. Runtime needs only
SELECT/INSERT/DELETE access to the Felix tables; setup additionally needs CREATE.

Run idempotent setup from project root:

```sh
php web/felix/tests/setup_assignments.php
```

Seeds 12 explicitly fictional people and 2026-11-12. It never reads or changes
Drupal persons or CSV rosters. No assignments are seeded; use the UI to add them.
Assignments are planning-only, not exported into the existing check-in flow.

## Date selection and roster header

The planning page has a date picker. A valid date with no assignments starts
empty; assigning the first person creates the filming day. Changing dates never
moves people from another day. Date selection alone does not create DB records.
The selected date is kept in the `?date=YYYY-MM-DD` URL, including the return link
to the roster, so a reload keeps the same date.

The roster header shows a separate filming-day date picker and the names assigned
to that date. This planning summary does not replace the currently selected CSV
roster or alter its check in / check out records. Every authenticated roster user
may read the summary through GET-only `filming_day.php`; assigning and removing
people remains restricted to Elek. The endpoint returns the selected day,
assigned people, and existing dates for the date-picker suggestions. Without an
explicit date, the earliest existing filming day is selected (or today's date in
Europe/Budapest when no days exist).

Invalid calendar dates are rejected server-side. The UI clears old names while a
new date loads and ignores stale responses. During a save, the planning date
picker is disabled and the request retains the date selected when saving began.

## Verification

```sh
web/felix/.venv/bin/python web/felix/tests/test_assignments.py
web/felix/.venv/bin/python web/felix/tests/test_assignment_dates.py
web/felix/.venv/bin/python web/felix/tests/test_assignment_date_ui.py
```

The database tests run temporary app copies and HTTP servers using session
fixtures (no passwords) and UUID-prefixed disposable MySQL tables. They check
authorization, CSRF, real calendar validation, real DB writes, rollback on SQL
failure, duplicate prevention, date isolation, search, reload persistence,
removal, and mobile browser navigation from planning to the roster header.
Existing live assignment tables and CSVs are not modified. Temporary tables are
dropped on cleanup. The UI contract test uses explicitly mocked API fixtures and
does not replace the real database/browser integration coverage.
Screenshot: `/workspace/tmp/felix-assignments-mobile.png`.

If no web server is running, a local preview can be started with:
`php -S 127.0.0.1:8088 -t /workspace/web`
Then open `http://127.0.0.1:8088/felix/assignments.php` and use the existing login.
