<?php
function felixValidFilmingDate($date): bool {
    return is_string($date)
        && preg_match('/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/D', $date)
        && checkdate((int)substr($date, 5, 2), (int)substr($date, 8, 2), (int)substr($date, 0, 4));
}

function felixDefaultFilmingDate(PDO $db): string {
    return $db->query('SELECT date FROM felix_filming_days ORDER BY date LIMIT 1')->fetchColumn()
        ?: (new DateTimeImmutable('now', new DateTimeZone('Europe/Budapest')))->format('Y-m-d');
}

function felixFilmingDay(PDO $db, string $date): array {
    $query = $db->prepare('SELECT id,date,title FROM felix_filming_days WHERE date=?');
    $query->execute([$date]);
    return $query->fetch() ?: ['id' => null, 'date' => $date, 'title' => 'Forgatási nap'];
}

function felixFilmingAssigned(PDO $db, $dayId): array {
    if ($dayId === null) return [];
    $query = $db->prepare('SELECT p.id,p.name,p.city,p.fictional FROM felix_people p JOIN felix_day_assignments a ON a.person_id=p.id WHERE a.day_id=? ORDER BY p.name');
    $query->execute([$dayId]);
    return $query->fetchAll();
}

function felixAssignmentsDb(): PDO {
    $path = getenv('FELIX_DB_CONFIG') ?: dirname(__DIR__, 2) . '/private/felix-db.php';
    if (!is_file($path)) throw new RuntimeException('Missing private database configuration');
    $c = require $path;
    return new PDO('mysql:host=' . $c['host'] . ';port=' . ($c['port'] ?: 3306) . ';dbname=' . $c['database'] . ';charset=utf8mb4', $c['username'], $c['password'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
}
