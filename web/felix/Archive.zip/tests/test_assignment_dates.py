"""Real HTTP/MySQL date tests; only UUID-namespaced disposable tables mutate."""
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import tempfile
import time
import unittest
import urllib.error
import urllib.parse
import urllib.request
import uuid
from typing import Any
from datetime import datetime
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parents[1]


class AssignmentDatesTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory(prefix='felix-dates-')
        cls.addClassCleanup(cls.tmp.cleanup)
        cls.app = Path(cls.tmp.name)
        cls.prefix = 'ft_' + uuid.uuid4().hex[:16]
        cls.env = dict(os.environ, FELIX_DB_CONFIG=os.environ.get('FELIX_DB_CONFIG', str(ROOT.parents[1] / 'private/felix-db.php')))
        def transform(text):
            return re.sub(r'\bfelix_(people|filming_days|day_assignments)\b', lambda m: cls.prefix + '_' + m[1], text)
        for name in ['auth.php', 'session_auth.php', 'assignments_auth.php', 'assignments_db.php', 'assignments_api.php', 'filming_day.php']:
            if (ROOT / name).exists():
                (cls.app / name).write_text(transform((ROOT / name).read_text()))
        # Execute the established connection helper; never read private config values.
        cls.addClassCleanup(cls.drop_tables)
        setup = (ROOT / 'tests/setup_assignments.php').read_text().replace("dirname(__DIR__) . '/assignments_db.php'", "__DIR__ . '/assignments_db.php'")
        (cls.app / 'setup.php').write_text(transform(setup))
        subprocess.run(['php', str(cls.app / 'setup.php')], env=cls.env, check=True, capture_output=True)
        cls.sql('DELETE FROM {p}_day_assignments; DELETE FROM {p}_filming_days;')
        for user in ['Elek', 'Kecsu']:
            (cls.app / ('sess_test' + user.lower() + '1234567890')).write_text(f'user|s:{len(user)}:"{user}";csrf|s:64:"' + 'a' * 64 + '";')
        with socket.socket() as sock:
            sock.bind(('127.0.0.1', 0))
            port = sock.getsockname()[1]
        cls.base = f'http://127.0.0.1:{port}/'
        cls.server = subprocess.Popen(['php', '-d', 'session.save_path=' + cls.tmp.name, '-S', f'127.0.0.1:{port}', '-t', cls.tmp.name], env=cls.env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        cls.addClassCleanup(cls.stop_server)
        for _ in range(60):
            try:
                cls.request('assignments_api.php', user=None)
                break
            except urllib.error.URLError:
                time.sleep(.05)
        else:
            raise RuntimeError('PHP server failed to start')

    @classmethod
    def stop_server(cls):
        cls.server.terminate()
        cls.server.wait(timeout=10)

    @classmethod
    def sql(cls, sql):
        code = 'require ' + json.dumps(str(cls.app / 'assignments_db.php')) + '; $db=felixAssignmentsDb(); $db->exec(' + json.dumps(sql.format(p=cls.prefix)) + ');'
        subprocess.run(['php', '-r', code], env=cls.env, check=True, capture_output=True)

    @classmethod
    def drop_tables(cls):
        cls.sql('DROP TABLE IF EXISTS {p}_day_assignments; DROP TABLE IF EXISTS {p}_filming_days; DROP TABLE IF EXISTS {p}_people;')

    def setUp(self):
        self.sql('DELETE FROM {p}_day_assignments; DELETE FROM {p}_filming_days;')

    @classmethod
    def request(cls, path, user: str | None = 'Elek', data=None) -> tuple[int, Any]:
        headers = {'Cookie': 'FELIXSESSID=test' + user.lower() + '1234567890'} if user else {}
        payload = urllib.parse.urlencode(data).encode() if data is not None else None
        try:
            response = urllib.request.urlopen(urllib.request.Request(cls.base + path, data=payload, headers=headers))
        except urllib.error.HTTPError as error:
            response = error
        body = response.read().decode()
        try:
            body = json.loads(body)
        except ValueError:
            pass
        return response.status, body

    def post(self, date, **kwargs):
        return self.request('assignments_api.php', data={'date': date, 'person_id': '1', 'action': 'assign', 'csrf': 'a' * 64, **kwargs})

    def test_new_assignment_persistence_duplicates_and_date_isolation(self):
        for _ in range(2):
            self.assertEqual(self.post('2028-02-29')[0], 200)
        first = self.request('assignments_api.php?date=2028-02-29')[1]
        self.assertIsNotNone(first['day']['id'])
        self.assertEqual([int(p['id']) for p in first['assigned']], [1])
        self.assertEqual(self.post('2028-03-01', person_id='2')[0], 200)
        second = self.request('assignments_api.php?date=2028-03-01')[1]
        self.assertEqual([int(p['id']) for p in second['assigned']], [2])
        self.assertEqual(self.post('2028-02-29', action='remove')[0], 200)
        self.assertEqual(self.request('assignments_api.php?date=2028-02-29')[1]['assigned'], [])
        self.assertEqual(self.request('assignments_api.php?date=2028-03-01')[1], second)

    def test_summary_reader_default_dates_and_authorization(self):
        today = datetime.now(ZoneInfo('Europe/Budapest')).strftime('%Y-%m-%d')
        for endpoint in ['filming_day.php', 'assignments_api.php']:
            for suffix in ['', '?date=']:
                status, body = self.request(endpoint + suffix)
                self.assertEqual(status, 200)
                self.assertEqual(body['day']['date'], today)
                self.assertIsNone(body['day']['id'])
        self.assertEqual(self.post('2028-03-01', person_id='2')[0], 200)
        self.assertEqual(self.post('2028-02-29')[0], 200)
        self.sql("UPDATE {p}_filming_days SET title='Preserved title' WHERE date='2028-02-29'")
        self.assertEqual(self.post('2028-02-29')[0], 200)
        status, body = self.request('filming_day.php', user='Kecsu')
        self.assertEqual(status, 200)
        self.assertEqual(set(body), {'day', 'assigned', 'days'})
        self.assertEqual(body['day']['date'], '2028-02-29')
        self.assertEqual(body['day']['title'], 'Preserved title')
        self.assertEqual([int(p['id']) for p in body['assigned']], [1])
        self.assertEqual(set(body['assigned'][0]), {'id', 'name', 'city', 'fictional'})
        self.assertEqual(body['days'], [{'date': '2028-02-29', 'title': 'Preserved title'}, {'date': '2028-03-01', 'title': 'Forgatási nap'}])
        self.assertEqual(self.request('assignments_api.php')[1]['day'], body['day'])
        selected = self.request('filming_day.php?date=2028-03-01', user='Kecsu')[1]
        self.assertEqual([int(p['id']) for p in selected['assigned']], [2])
        missing = self.request('filming_day.php?date=2030-01-01', user='Kecsu')[1]
        self.assertEqual(missing['day'], {'id': None, 'date': '2030-01-01', 'title': 'Forgatási nap'})
        self.assertEqual(missing['assigned'], [])
        for user in ['Elek', 'Kecsu']:
            self.assertEqual(self.request('filming_day.php', user=user, data={'date': '2030-01-01'})[0], 405)
        self.assertEqual(self.request('filming_day.php', user=None)[0], 401)
        for data in [None, {'action': 'assign'}]:
            self.assertEqual(self.request('assignments_api.php', user='Kecsu', data=data)[0], 403)
            self.assertEqual(self.request('assignments_api.php', user=None, data=data)[0], 401)
        for date in ['0000-01-01', '2026-02-29', '2026-04-31', 'garbage']:
            self.assertEqual(self.request('filming_day.php?date=' + date, user='Kecsu')[0], 400)
        self.assertEqual(self.request('filming_day.php?date[]=2028-02-29')[0], 400)
        self.assertEqual(self.request('filming_day.php', user='Kecsu')[1], body)

    def test_remove_and_invalid_posts_never_create_days(self):
        for _ in range(2):
            self.assertEqual(self.post('2031-01-01', action='remove')[0], 200)
        for changes in [{'person_id': '999999'}, {'person_id': '0'}, {'person_id': '-1'}, {'person_id': '1 OR 1=1'}, {'action': 'bad'}]:
            self.assertEqual(self.post('2031-01-01', **changes)[0], 400)
        self.assertEqual(self.post('2031-01-01', csrf='bad')[0], 403)
        self.assertEqual(self.request('filming_day.php')[1]['days'], [])

    def test_assignment_failure_rolls_back_new_day(self):
        # Real SQL constraint failure after day insertion; no mocked database.
        self.sql("ALTER TABLE {p}_day_assignments ADD CONSTRAINT {p}_reject CHECK (person_id <> 1)")
        try:
            self.assertEqual(self.post('2032-01-01')[0], 503)
            self.assertEqual(self.request('filming_day.php')[1]['days'], [])
            self.assertIsNone(self.request('assignments_api.php?date=2032-01-01')[1]['day']['id'])
        finally:
            self.sql('ALTER TABLE {p}_day_assignments DROP CONSTRAINT {p}_reject')
        self.assertEqual(self.post('2032-01-01')[0], 200)

    def test_invalid_calendar_dates(self):
        for date in ['0000-01-01', '2026-02-29', '2026-04-31', '2026-13-01', '2026-00-12', '2026-01-00', '2026-1-01', '2026-01-01\n', '2026-01-01junk']:
            with self.subTest(date=date):
                self.assertEqual(self.request('assignments_api.php?date=' + urllib.parse.quote(date))[0], 400)
                self.assertEqual(self.post(date)[0], 400)
        self.assertEqual(self.request('assignments_api.php?date[]=2026-01-01')[0], 400)

    def test_nonexistent_date_is_read_only(self):
        status, body = self.request('assignments_api.php?date=2028-02-29')
        self.assertEqual(status, 200)
        self.assertEqual(body['day'], {'id': None, 'date': '2028-02-29', 'title': 'Forgatási nap'})
        self.assertEqual(body['assigned'], [])
        self.assertEqual(len(body['people']), 12)
        self.sql("INSERT INTO {p}_filming_days (date,title) VALUES ('2028-02-29','Read did not create a row')")


if __name__ == '__main__':
    unittest.main(verbosity=2)
