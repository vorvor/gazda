<?php
// CLI-only, idempotent fictional demo seed. Never imports roster/Drupal persons.
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require dirname(__DIR__) . '/assignments_db.php';
$db = felixAssignmentsDb();
$db->exec("CREATE TABLE IF NOT EXISTS felix_people (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, demo_key VARCHAR(40) NOT NULL UNIQUE, name VARCHAR(120) NOT NULL, city VARCHAR(80) NOT NULL, fictional TINYINT NOT NULL DEFAULT 1) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$db->exec("CREATE TABLE IF NOT EXISTS felix_filming_days (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, date DATE NOT NULL UNIQUE, title VARCHAR(160) NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$db->exec("CREATE TABLE IF NOT EXISTS felix_day_assignments (day_id INT UNSIGNED NOT NULL, person_id INT UNSIGNED NOT NULL, assigned_by VARCHAR(80) NOT NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(day_id,person_id), FOREIGN KEY(day_id) REFERENCES felix_filming_days(id), FOREIGN KEY(person_id) REFERENCES felix_people(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$db->beginTransaction();
$insert = $db->prepare('INSERT INTO felix_people (demo_key,name,city) VALUES (?,?,?) ON DUPLICATE KEY UPDATE demo_key=VALUES(demo_key)');
foreach ([['Almavirág Anna','Budapest'],['Bársony Bence','Szentendre'],['Csillag Cili','Vác'],['Dióliget Dániel','Budapest'],['Ezüst Eszter','Gödöllő'],['Felhő Ferenc','Érd'],['Gyöngy Gréta','Budapest'],['Harmat Henrik','Dunakeszi'],['Ibolya Ilona','Szentendre'],['Juhar Júlia','Budapest'],['Kökény Kristóf','Vác'],['Levendula Lili','Érd']] as $i => $person) $insert->execute(['fictional-' . ($i+1), $person[0], $person[1]]);
$db->prepare('INSERT INTO felix_filming_days (date,title) VALUES (?,?) ON DUPLICATE KEY UPDATE date=VALUES(date)')->execute(['2026-11-12','Novemberi próbaforgatás · fiktív bemutató']);
$db->commit();
print json_encode(['people' => $db->query('SELECT COUNT(*) FROM felix_people WHERE fictional=1')->fetchColumn(), 'day' => $db->query("SELECT date,title FROM felix_filming_days WHERE date='2026-11-12'")->fetch()], JSON_UNESCAPED_UNICODE) . "\n";
